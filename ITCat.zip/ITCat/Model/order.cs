﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Model
{
    public class Order
    {
        /// <summary>
        /// 订单ID
        /// </summary>
        public int OrderID { get; set; }
    }
}